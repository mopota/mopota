import 'dart:async';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:adhan/adhan.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:audioplayers/audioplayers.dart';
import 'package:hesnelmuslim/cubit_states/states.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:intl/intl.dart';
import '../modules/azan_screen.dart';
import '../shared/network/local/cach_helper.dart';

/// ======================= AppCubit after full adjustment ============================

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

class AppCubit extends Cubit<AppStates> {
  final GlobalKey<NavigatorState> navigatorKey;

  AppCubit({required this.navigatorKey}) : super(AppInitialStates());

  static AppCubit get(context) => BlocProvider.of(context);

  double scale = 1.0;
  final Coordinates coordinates = Coordinates(30.0444, 31.2357); // Cairo
  late PrayerTimes prayerTimes;
  final Color black = Colors.black;
  final Color blue = HexColor("#3F51B5");
  final Color white = Colors.white;
  final formatter = DateFormat.jm();
  final hijri = HijriCalendar.now();

  ThemeMode appMode = ThemeMode.dark;
  bool isDark = false;

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
  final AudioPlayer _audioPlayer = AudioPlayer();

  List<Timer> _timers = [];

  void changeAppMode({bool? fromShared}) {
    if (fromShared != null) {
      isDark = fromShared;
      emit(AppChangeModeState());
    } else {
      isDark = !isDark;
      CachHelper.putData(key: "isDark", value: isDark).then((value) {
        emit(AppChangeModeState());
      });
    }
  }

  Future<void> initializeNotifications() async {
    tz.initializeTimeZones();
    await _initNotificationPlugin();
    await AndroidAlarmManager.initialize();
    await loadPrayerTimesAndSchedule();
    await scheduleQiyamReminder();
  }

  Future<void> _initNotificationPlugin() async {
    const AndroidInitializationSettings androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const InitializationSettings initSettings = InitializationSettings(android: androidSettings);

    await flutterLocalNotificationsPlugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        final payload = response.payload ?? "";
        if (payload == "azan") {
          navigatorKey.currentState?.push(
            MaterialPageRoute(
              builder: (context) => AzanScreen(prayerName: "الأذان"),
            ),
          );
        }
      },
    );
  }

  Future<void> loadPrayerTimesAndSchedule() async {
    final params = CalculationMethod.egyptian.getParameters();
    final now = DateTime.now();
    final dateComponents = DateComponents(now.year, now.month, now.day);
    prayerTimes = PrayerTimes(coordinates, dateComponents, params);

    final Map<Prayer, DateTime?> times = {
      Prayer.fajr: prayerTimes.fajr,
      Prayer.dhuhr: prayerTimes.dhuhr,
      Prayer.asr: prayerTimes.asr,
      Prayer.maghrib: prayerTimes.maghrib,
      Prayer.isha: prayerTimes.isha,
    };

    for (final t in _timers) {
      t.cancel();
    }
    _timers.clear();

    int uniqueId = 1000;
    for (final prayer in times.keys) {
      final time = times[prayer];
      if (time == null || time.isBefore(now)) continue;

      final reminderTime = time.subtract(const Duration(minutes: 15));
      if (reminderTime.isAfter(now)) {
        await scheduleNotification(
          id: uniqueId++,
          title: "اقترب وقت ${prayerName(prayer)}",
          body: "باقي ١٥ دقيقة على صلاة ${prayerName(prayer)}",
          scheduledTime: reminderTime,
          sound: '${prayer.name}_reminder',
          payload: "reminder_${prayerName(prayer)}",
        );
      }

      await scheduleNotification(
        id: uniqueId++,
        title: "حان الآن وقت ${prayerName(prayer)}",
        body: "الله أكبر، الله أكبر ...",
        scheduledTime: time,
        sound: "azan",
        payload: "azan",
      );

      await AndroidAlarmManager.oneShotAt(
        time,
        uniqueId++,
        azanCallback,
        exact: true,
        wakeup: true,
        rescheduleOnReboot: true,
      );
    }
  }

  Future<void> scheduleQiyamReminder() async {
    final now = DateTime.now();
    DateTime targetTime = DateTime(now.year, now.month, now.day, 22, 30);

    if (targetTime.isBefore(now)) {
      targetTime = targetTime.add(const Duration(days: 1));
    }

    await scheduleNotification(
      id: 9999,
      title: '🌙 تذكير لقيام الليل',
      body: 'افتح قلبك.. حان وقت قيام الليل 🤲',
      scheduledTime: targetTime,
      sound: 'qiyam',
      payload: "qiyam",
    );

    _timers.add(
      Timer(targetTime.difference(now), () {
        playQiyam();
      }),
    );
  }

  Future<void> scheduleNotification({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledTime,
    required String sound,
    required String payload,
  }) async {
    final AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'prayer_channel',
      'Prayer Notifications',
      channelDescription: 'تنبيهات أوقات الصلاة',
      importance: Importance.max,
      priority: Priority.high,
      sound: RawResourceAndroidNotificationSound(sound),
    );
    final NotificationDetails notificationDetails = NotificationDetails(
      android: androidDetails,
    );
    await flutterLocalNotificationsPlugin.zonedSchedule(
      id,
      title,
      body,
      tz.TZDateTime.from(scheduledTime, tz.local),
      notificationDetails,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      payload: payload,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  void playQiyam() async {
    await _audioPlayer.play(AssetSource('sounds/qiyam.mp3'));
    navigatorKey.currentState?.push(
      MaterialPageRoute(
        builder: (context) => AzanScreen(prayerName: "قيام الليل"),
      ),
    );
    debugPrint("🔔 تشغيل تنبيه قيام الليل");
  }

  void playReminder(Prayer prayer) async {
    final fileName = '${prayer.name}_reminder.mp3';
    await _audioPlayer.play(AssetSource('sounds/$fileName'));
    debugPrint("اقترب وقت صلاة ${prayerName(prayer)}");
  }

  void playAzan(Prayer prayer) {
    FlutterBackgroundService().startService();
    navigatorKey.currentState?.push(
      MaterialPageRoute(
        builder: (context) => AzanScreen(prayerName: prayerName(prayer)),
      ),
    );
    debugPrint("حان وقت صلاة ${prayerName(prayer)}");
  }

  String prayerName(Prayer prayer) {
    switch (prayer) {
      case Prayer.fajr:
        return "الفجر";
      case Prayer.dhuhr:
        return "الظهر";
      case Prayer.asr:
        return "العصر";
      case Prayer.maghrib:
        return "المغرب";
      case Prayer.isha:
        return "العشاء";
      default:
        return "";
    }
  }

  List<dynamic> favorites = [];

  void addToFavorites(dynamic item) {
    if (!favorites.contains(item)) {
      favorites.add(item);
      emit(AddToFavoritesState());
    }
  }

  void removeFromFavorites(dynamic item) {
    favorites.remove(item);
    emit(AppFavoritesUpdatedState());
  }

  List<dynamic> getFavorites() {
    return favorites;
  }

  @override
  Future<void> close() {
    for (final t in _timers) {
      t.cancel();
    }
    return super.close();
  }
}

@pragma('vm:entry-point')
void azanCallback() async {
  final player = AudioPlayer();
  await player.play(AssetSource('sounds/azan.mp3'));
  FlutterBackgroundService().startService();

  if (navigatorKey.currentState != null) {
    navigatorKey.currentState?.push(
      MaterialPageRoute(
        builder: (context) => AzanScreen(prayerName: "الأذان"),
      ),
    );
  }

  debugPrint("🕌 وقت الأذان (azanCallback)!");
}

@pragma('vm:entry-point')
void qiyamCallback() async {
  debugPrint("🌙 وقت قيام الليل (qiyamCallback)!");
}
