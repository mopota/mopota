import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'package:audioplayers/audioplayers.dart';

void initializeService() async {
  final service = FlutterBackgroundService();

  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onStart,
      isForegroundMode: true,
      autoStart: false,
      notificationChannelId: 'azanchannel',
      initialNotificationTitle: 'تشغيل الأذان',
      initialNotificationContent: 'جاري تشغيل الأذان...',
      foregroundServiceNotificationId: 999,
    ),
    iosConfiguration: IosConfiguration(),
  );
}

@pragma('vm:entry-point')
void onStart(ServiceInstance service) async {
  AudioPlayer player = AudioPlayer();

  await player.play(AssetSource('sounds/azan.mp3'));

  // بعد انتهاء الأذان، نوقف الخدمة
  player.onPlayerComplete.listen((event) {
    service.stopSelf();
  });
}
