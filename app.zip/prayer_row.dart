import 'package:flutter/material.dart';

class PrayerRow extends StatelessWidget {
  final String name;
  final String time;
  final Color background;
  final String? title;
  final String? imageAsset;
  final Color textColor;

  const PrayerRow({
    Key? key,
    required this.name,
    required this.time,
    required this.background,
    required this.textColor,
    this.title,
    this.imageAsset,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  Container(
      width: 120,
      height: 120,
      margin: const EdgeInsets.all(3),
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(name,
              style: TextStyle(
                  fontWeight: FontWeight.bold, fontSize: 18, color: textColor)),
          Text(time, style: TextStyle(fontSize: 16, color: textColor)),
        ],
      ),

    );

  }
}