import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:audioplayers/audioplayers.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

@pragma('vm:entry-point')
void qiyamCallback() async {
  // لازم تعيد تهيئة notification
  const AndroidInitializationSettings androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');

  const InitializationSettings initSettings = InitializationSettings(android: androidSettings);

  await flutterLocalNotificationsPlugin.initialize(initSettings);

  // Show notification
  const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
    'qiyam_channel',
    'قيام الليل',
    channelDescription: 'تنبيه قيام الليل',
    importance: Importance.max,
    priority: Priority.high,
    sound: RawResourceAndroidNotificationSound('qiyam'),
  );

  const NotificationDetails notificationDetails = NotificationDetails(android: androidDetails);

  await flutterLocalNotificationsPlugin.show(
    999,
    '🌙 وقت قيام الليل',
    'استعد للقيام!',
    notificationDetails,
    payload: 'qiyam',
  );

  // Play qiyam.mp3
  final player = AudioPlayer();
  await player.play(AssetSource('sounds/qiyam.mp3'));

  print("🔥 اشتغل تنبيه قيام الليل حتى لو التطبيق مقفول!");
}
