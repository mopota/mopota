import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';

class AzanScreen extends StatefulWidget {
  final String prayerName;

  const AzanScreen({required this.prayerName, Key? key}) : super(key: key);

  @override
  State<AzanScreen> createState() => _AzanScreenState();
}

class _AzanScreenState extends State<AzanScreen> {
  final AudioPlayer player = AudioPlayer();

  @override
  void initState() {
    super.initState();
    playAzan();
  }

  @override
  void dispose() {
    player.stop();
    super.dispose();
  }

  Future<void> playAzan() async {
    FlutterBackgroundService().startService();

    await player.play(AssetSource('sounds/azan.mp3'));
  }

  Future<void> stopAzan() async {
    await player.stop();
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        decoration: BoxDecoration(
        image: DecorationImage(
        image: AssetImage('assets/images/azan_bg.jpeg'), // حط هنا صورة الخلفية بتاعتك
    fit: BoxFit.cover, // عشان الصورة تغطي الشاشة كلها
    ),
        ),
        child: Center(
          child: SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  "🕌 حان الآن وقت",
                  style: TextStyle(fontSize: 24, color: Colors.white),
                ),
                const SizedBox(height: 10),
                Text(
                  widget.prayerName,
                  style: const TextStyle(
                    fontSize: 48,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 30),
                ElevatedButton.icon(
                  onPressed: stopAzan,
                  icon: const Icon(Icons.stop_circle, size: 32),
                  label: const Text('إيقاف الأذان', style: TextStyle(fontSize: 20)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                    padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}