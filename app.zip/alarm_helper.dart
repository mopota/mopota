import 'dart:isolate';
import 'dart:ui';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest_all.dart' as tz;

const String azanIsolateName = 'azan_isolate';
int uniqueId = 1000;

// ======= callback اللي بيشتغل وقت التنبيه ========
@pragma('vm:entry-point')
void azanCallback() async {
  final player = AudioPlayer();
  await player.play(AssetSource('sounds/azan.mp3'));
}

// ======= callback للتنبيه قبل الصلاة ========
@pragma('vm:entry-point')
void reminderCallback() async {
  final player = AudioPlayer();
  await player.play(AssetSource('sounds/reminder.mp3')); // صوت "اقترب وقت الصلاة"
}

// ======= دالة حجز الصلاة ========
Future<void> schedulePrayer({
  required DateTime prayerTime,
}) async {
  // وقت التنبيه قبل الصلاة بـ 15 دقيقة
  final DateTime reminderTime = prayerTime.subtract(const Duration(minutes: 15));

  await AndroidAlarmManager.oneShotAt(
    reminderTime,
    uniqueId++,
    reminderCallback,
    exact: true,
    wakeup: true,
    rescheduleOnReboot: true,
  );

  // حجز الأذان وقت الصلاة
  await AndroidAlarmManager.oneShotAt(
    prayerTime,
    uniqueId++,
    azanCallback,
    exact: true,
    wakeup: true,
    rescheduleOnReboot: true,
  );
}
